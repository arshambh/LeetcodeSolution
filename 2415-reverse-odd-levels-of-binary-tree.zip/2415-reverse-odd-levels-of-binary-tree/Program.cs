﻿namespace LeetCode
{
    // https://leetcode.com/problems/reverse-odd-levels-of-binary-tree/description/
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            // ایجاد یک درخت دودویی با ریشه دارای مقدار 2
            TreeNode node = new TreeNode(2)
            {
                left = new TreeNode(3)
                {
                    left = new TreeNode(8),
                    right = new TreeNode(13)
                },
                right = new TreeNode(5)
                {
                    left = new TreeNode(21),
                    right = new TreeNode(34)
                }
            };
            // فراخوانی تابع برای معکوس کردن سطوح فرد درخت
            var res = ReverseOddLevels(node);
        }

        // معکوس کردن مقادیر نودها در سطوح فرد درخت دودویی
        public static TreeNode? ReverseOddLevels(TreeNode? root)
        {
            if (root == null)
                return null; // اگر ریشه وجود نداشت، null برگردانده می‌شود

            Queue<TreeNode> queue = new Queue<TreeNode>();
            queue.Enqueue(root);
            int level = 0;

            while (queue.Count > 0)
            {
                int size = queue.Count; // تعداد نودها در سطح فعلی
                List<TreeNode> levelNodes = new List<TreeNode>(); // لیستی برای نگهداری نودهای هر سطح

                for (int i = 0; i < size; i++)
                {
                    TreeNode node = queue.Dequeue();
                    levelNodes.Add(node);

                    // اضافه کردن فرزندان چپ و راست به صف اگر وجود داشته باشند
                    if (node.left != null)
                    {
                        queue.Enqueue(node.left);
                        queue.Enqueue(node.right);
                    }
                }

                // اگر سطح فرد است، مقادیر نودها را معکوس کن
                if (level % 2 != 0)
                {
                    int left = 0, right = levelNodes.Count - 1;
                    while (left < right)
                    {
                        // تعویض مقادیر نودها از دو سر لیست
                        (levelNodes[left].val, levelNodes[right].val) = (levelNodes[right].val, levelNodes[left].val);
                        left++;
                        right--;
                    }
                }
                level++; // افزایش شمارنده سطح برای سطح بعدی
            }
            return root; // بازگرداندن ریشه درخت با تغییرات اعمال شده
        }

        public class TreeNode
        {
            public int val;
            public TreeNode left;
            public TreeNode right;
            public TreeNode(int val = 0, TreeNode left = null, TreeNode right = null)
            {
                this.val = val;
                this.left = left;
                this.right = right;
            }
        }

    }

}
