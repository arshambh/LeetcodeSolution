﻿namespace LeetCode
{
    // https://leetcode.com/problems/final-array-state-after-k-multiplication-operations-i/description/
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            var res = GetFinalState([2, 1, 3, 5, 6], 5, 2);
        }
        public static int[] GetFinalState(int[] nums, int k, int multiplier)
        {
            // ایجاد یک مجموعه مرتب (SortedSet) برای ذخیره مقادیر آرایه به همراه ایندکس‌هایشان
            // این مجموعه به ما کمک می‌کند که کوچک‌ترین مقدار را به راحتی پیدا کنیم
            var minList = new SortedSet<(int value, int index)>();

            // اضافه کردن تمام مقادیر آرایه به مجموعه مرتب
            for (int i = 0; i < nums.Length; i++)
            {
                minList.Add((nums[i], i)); // هر مقدار به همراه ایندکس آن اضافه می‌شود
            }

            // انجام k عملیات
            for (int i = 0; i < k; i++)
            {
                // پیدا کردن کوچک‌ترین مقدار از مجموعه مرتب
                var minElement = minList.Min; // کوچک‌ترین مقدار همیشه اولین عنصر مجموعه است
                minList.Remove(minElement); // حذف کوچک‌ترین مقدار از مجموعه

                // ضرب کردن کوچک‌ترین مقدار در multiplier و به‌روزرسانی مقدار در آرایه
                nums[minElement.index] *= multiplier;

                // اضافه کردن مقدار جدید به مجموعه مرتب
                minList.Add((nums[minElement.index], minElement.index));
            }

            // بازگرداندن آرایه نهایی پس از انجام تمام عملیات
            return nums;
        }
    }
}
