﻿namespace Leetcode
{
    // https://leetcode.com/problems/add-two-numbers/description/
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            // ایجاد لیست‌های لینک شده برای آزمایش
            ListNode l1 = new ListNode(9, new ListNode(9, new ListNode(9, new ListNode(9, new ListNode(9, new ListNode(9, new ListNode(9)))))));
            ListNode l2 = new ListNode(9, new ListNode(9, new ListNode(9, new ListNode(9))));

            // جمع دو لیست لینک شده
            var sumList = AddTwoNumbers(l1, l2);
        }

        public static ListNode AddTwoNumbers(ListNode l1, ListNode l2)
        {
            // ایجاد یک نود برای شروع لیست جدید
            ListNode listNode = new ListNode(0);
            ListNode p = l1, q = l2, current = listNode;
            int extra = 0; // مقدار اضافی برای حمل

            // تا زمانی که هر کدام از لیست‌ها به پایان نرسیده‌اند ادامه دهید
            while (p != null || q != null)
            {
                // مقدار نود فعلی اولین لیست، اگر وجود داشته باشد
                var x = p?.val ?? 0;
                // مقدار نود فعلی دومین لیست، اگر وجود داشته باشد
                var y = q?.val ?? 0;

                // محاسبه جمع مقادیر و مقدار اضافی
                var sum = x + y + extra;
                extra = sum / 10; // مقدار اضافی برای نود بعدی
                var remain = sum % 10; // باقی مانده برای نود جدید

                // ایجاد نود جدید با مقدار باقی‌مانده
                current.next = new ListNode(remain);
                current = current.next;

                // حرکت به نود بعدی لیست اول
                if (p != null)
                    p = p.next;

                // حرکت به نود بعدی لیست دوم
                if (q != null)
                    q = q.next;
            }

            // اگر هنوز مقدار اضافی داریم، یک نود جدید ایجاد کنید
            if (extra > 0)
            {
                current.next = new ListNode(extra);
            }
            // برگشت لیست جدید، بدون نود ابتدایی که فقط برای شروع بود
            return listNode.next;
        }

        // تعریف کلاس نود لیست لینک شده
        public class ListNode(int val = 0, ListNode next = null)
        {
            public int val = val;
            public ListNode next = next;
        }
    }
}