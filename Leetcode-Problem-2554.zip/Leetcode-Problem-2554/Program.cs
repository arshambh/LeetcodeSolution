﻿namespace Leetcode
{
    internal class Program
    {
// آدرس سوال
// https://leetcode.com/problems/maximum-number-of-integers-to-choose-from-a-range-i/description/
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            // آزمایش توابع MaxCount با نمونه‌های مختلف
            var res1 = MaxCount([1, 6, 5], 5, 6);
            var res2 = MaxCount([1, 2, 3, 4, 5, 6, 7], 8, 1);
            var res3 = MaxCount([11], 7, 50);
        }

        /// <summary>
        /// محاسبه حداکثر تعداد اعداد صحیح از بازه [1, n] که می‌توان انتخاب کرد 
        /// بدون این که مجموع آنها از maxSum بیشتر شود، در حالی که اعداد در لیست banned ممنوع هستند.
        /// </summary>
        /// <param name="banned">لیست اعدادی که نمی‌توان انتخاب کرد.</param>
        /// <param name="n">حد بالای بازه برای انتخاب.</param>
        /// <param name="maxSum">حداکثر مجموع اعدادی که می‌توان انتخاب کرد.</param>
        /// <returns>تعداد اعدادی که می‌توان انتخاب کرد.</returns>
        public static int MaxCount(int[] banned, int n, int maxSum)
        {
            // تبدیل آرایه banned به HashSet برای زمان جستجو O(1)
            HashSet<int> hashSet = [.. banned];

            int currentSum = 0; // مجموع اعداد انتخاب شده
            int counter = 0;    // تعداد اعداد انتخاب شده

            for (int i = 1; i <= n; i++)
            {
                // اگر عدد در لیست ممنوعه بود، آن را نادیده بگیر
                if (hashSet.Contains(i))
                    continue;

                // بررسی اینکه آیا اضافه کردن این عدد مجموع را از maxSum بیشتر می‌کند یا نه
                if (currentSum + i > maxSum)
                    break;

                currentSum += i;
                counter++;
            }

            return counter;
        }
    }
}