﻿namespace LeetCode
{
    // https://leetcode.com/problems/take-gifts-from-the-richest-pile/description/
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            var res = PickGifts([25, 64, 9, 4, 100], 4);

        }
        public static long PickGifts(int[] gifts, int k)
        {

            for (int i = 0; i < k; i++)
            {
                int maxIndex = 0;
                for (int j = 1; j < gifts.Length; j++)
                {
                    if (gifts[j] > gifts[maxIndex])
                    {
                        maxIndex = j;
                    }
                }
                gifts[maxIndex] = (int)Math.Floor(Math.Sqrt(gifts[maxIndex]));
            }
            long total = 0;
            for (int j = 0; j < gifts.Length; j++)
            {
                total += gifts[j];
            }

            return total;
        }
    }
}
