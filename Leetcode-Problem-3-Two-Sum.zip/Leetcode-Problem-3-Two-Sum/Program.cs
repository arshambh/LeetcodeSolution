﻿namespace Leetcode
{
    // https://leetcode.com/problems/two-sum/description/
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            // فراخوانی تابع TwoSum با آرایه [3, 2, 4] و هدف 6
            var res = TwoSum(new int[] { 3, 2, 4 }, 6);
        }

        public static int[] TwoSum(int[] nums, int target)
        {
            // تعریف یک دیکشنری برای ذخیره مقادیر آرایه و ایندکس‌های آن‌ها
            Dictionary<int, int> intDics = new Dictionary<int, int>();

            // پیمایش آرایه
            for (int i = 0; i < nums.Length; i++)
            {
                // محاسبه اختلاف بین مقدار هدف و عنصر فعلی آرایه
                int dif = target - nums[i];

                // بررسی اینکه آیا اختلاف در دیکشنری وجود دارد یا خیر
                if (intDics.TryGetValue(dif, out var index))
                {
                    // اگر اختلاف پیدا شد، ایندکس‌های دو عدد را برمی‌گرداند
                    return new int[] { index, i };
                }

                // اگر اختلاف پیدا نشد، مقدار فعلی آرایه و ایندکس آن را به دیکشنری اضافه می‌کنیم
                intDics[nums[i]] = i;
            }

            // اگر هیچ جفتی پیدا نشد، یک آرایه خالی برمی‌گرداند
            return Array.Empty<int>();
        }

    
    }
}