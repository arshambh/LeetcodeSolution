﻿namespace Leetcode
{
    // https://leetcode.com/problems/two-sum/description/
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            var res = TwoSum([3, 2, 4], 6);
        }

        public static int[] TwoSum(int[] nums, int target)
        {
            Dictionary<int,int> intDics=new Dictionary<int,int>();
            for (int i = 0; i < nums.Length; i++)
            {
                int dif = target - nums[i];
                if (intDics.TryGetValue(dif, out var index))
                {
                    return new int[] { index, i };
                }

                intDics[nums[i]] = i;
            }
            return Array.Empty<int>();
        }

    
    }
}