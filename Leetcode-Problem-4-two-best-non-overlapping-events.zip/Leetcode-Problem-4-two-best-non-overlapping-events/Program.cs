﻿namespace Leetcode
{
    // https://leetcode.com/problems/two-best-non-overlapping-events/description/
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            // فراخوانی تابع MaxTwoEvents با آرایه‌ای از رویدادها
            var res = MaxTwoEvents([[1, 5, 3], [1, 5, 1], [6, 6, 5]]);
        }

        public static int MaxTwoEvents(int[][] events)
        {
            // مرتب‌سازی آرایه رویدادها بر اساس زمان پایان (اندیس 1)
            Array.Sort(events, (a, b) => a[1].CompareTo(b[1]));
            int n = events.Length;

            // آرایه‌ای برای ذخیره حداکثر مقدار تا هر رویداد
            int[] maxValue = new int[n];
            maxValue[0] = events[0][2]; // مقدار اولین رویداد

            // محاسبه حداکثر مقدار تا هر رویداد
            for (int i = 1; i < n; i++)
            {
                maxValue[i] = Math.Max(maxValue[i - 1], events[i][2]);
            }

            int maxSum = 0; // متغیر برای ذخیره حداکثر مجموع مقادیر

            // بررسی هر رویداد برای یافتن حداکثر مجموع دو رویداد غیرهمپوشان
            for (int i = 0; i < n; i++)
            {
                int currentValue = events[i][2]; // مقدار رویداد جاری

                int left = 0, right = i - 1, bestIndex = -1;

                // جستجوی دودویی برای یافتن نزدیک‌ترین رویداد قبلی که با رویداد جاری همپوشانی ندارد
                while (left <= right)
                {
                    int mid = (left + right) / 2;

                    int endTime = events[mid][1]; // زمان پایان رویداد میانی
                    int startTime = events[i][0]; // زمان شروع رویداد جاری

                    if (endTime < startTime)
                    {
                        bestIndex = mid; // به‌روزرسانی بهترین اندیس
                        left = mid + 1; // جستجو در نیمه راست
                    }
                    else
                    {
                        right = mid - 1; // جستجو در نیمه چپ
                    }
                }

                // محاسبه حداکثر مجموع با استفاده از رویداد جاری و بهترین رویداد قبلی
                if (bestIndex != -1)
                    maxSum = Math.Max(maxSum, (currentValue + maxValue[bestIndex]));
                else
                    maxSum = Math.Max(maxSum, currentValue); // اگر رویداد قبلی وجود نداشت، فقط مقدار رویداد جاری را در نظر بگیر

            }

            return maxSum; // بازگشت حداکثر مجموع
        }

    }
}